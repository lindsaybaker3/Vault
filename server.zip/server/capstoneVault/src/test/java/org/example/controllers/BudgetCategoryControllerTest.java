package org.example.controllers;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BudgetCategoryControllerTest {

    @Test
    void findAllBudgetCategories() {
    }

    @Test
    void findByBudgetCategoryId() {
    }
}