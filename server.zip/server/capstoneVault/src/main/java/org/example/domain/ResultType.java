package org.example.domain;

public enum ResultType {
    SUCCESS,
    INVALID,
    NOT_FOUND
}