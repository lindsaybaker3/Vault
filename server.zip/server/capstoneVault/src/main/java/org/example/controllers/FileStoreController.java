//package org.example.controllers;
//
//import com.amazonaws.HttpMethod;
//import org.example.domain.FileStoreService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.UUID;
//
//@RestController
//@RequestMapping("/api/vault")
//public class FileStoreController {
//
//    @Autowired
//    private FileStoreService service;
//
//    // Upload the file
//    @PostMapping("/upload/{url}")
//    public ResponseEntity<String> fileUploadUrl(@RequestParam String extension) {
//        return ResponseEntity.ok(service.generateUrl(UUID.randomUUID() + "_" + extension, HttpMethod.PUT));
//    }
//
//    // Download the file from the bucket
//    @GetMapping("/download/{url}")
//    public ResponseEntity<String> fileDownloadUrl(@RequestParam String filename) {
//        return ResponseEntity.ok(service.generateUrl(filename, HttpMethod.GET));
//    }
//
//    // Upload the file with JWT authorization
//    @PostMapping("/uploadurlWithAuth")
//    public ResponseEntity<String> fileUploadUrlWithAuth(@RequestParam String extension, @RequestHeader("Authorization") String authToken) {
//        // Extract user ID from the JWT token
//        String userId = extractUserIdFromToken(authToken);
//
//        // Generate a unique filename with the user's ID
//        String filename = userId + "_" + UUID.randomUUID() + "_" + extension;
//
//        // Store the filename and user ID in your database or storage
//        storeFileMetadata(filename, userId);
//
//        // Generate and return the pre-signed URL
//        return ResponseEntity.ok(service.generateUrl(filename, HttpMethod.PUT));
//    }
//
//    // Implement the extractUserIdFromToken and storeFileMetadata methods here
//}



import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

@RestController
@RequestMapping("/api/aws")
public class AWSController {

    @Autowired
    private AmazonS3 amazonS3;

    private static final String BUCKET_NAME = "seu-bucket-name"; // Substitua pelo nome do seu bucket

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            String fileName = file.getOriginalFilename();
            InputStream inputStream = file.getInputStream();
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(file.getSize());

            amazonS3.putObject(BUCKET_NAME, fileName, inputStream, metadata);

            return ResponseEntity.status(HttpStatus.CREATED).body("Arquivo enviado com sucesso para o Amazon S3!");
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao enviar arquivo para o Amazon S3.");
        }
    }

    @GetMapping("/download/{fileName}")
    public ResponseEntity<InputStreamResource> downloadFile(@PathVariable String fileName) {
        try {
            InputStream inputStream = amazonS3.getObject(BUCKET_NAME, fileName).getObjectContent();
            ObjectMetadata metadata = amazonS3.getObjectMetadata(BUCKET_NAME, fileName);

            return ResponseEntity.ok()
                    .contentLength(metadata.getContentLength())
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new InputStreamResource(inputStream));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}
